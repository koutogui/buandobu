<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Formulaire de diagnostic</title>
	<meta charset="UTF-8">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
</head>
<body class="bodyBg" style="background-image : url('images/bg-02c.jpg');">


	<div class="container-medical">
		<div class="wrap-medical">
			<div class="medical-form-title" style="background-image: url(images/bg-01.jpg);">
				<span class="nom-formulaire">
					FICHE DE DIAGNOSTIC
				</span>
				<span class="nom-patient">
					Nom du patient
				</span></br>
				<span class="ID-patient">
					IDENTIFIANT
				</span>
			</div>

			<form class="medical-form validate-form" action="collecte.php">	
<!--ligne de saisie un diagnostic-->
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Diagnostic</span>
					<textarea class="input100" name="diagnostic" placeholder="Ecrire ici"></textarea>
					<span class="focus-input100"></span>
				</div>
<!--ligne de saisie un traitement-->			
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Traitement</span>
					<textarea class="input100" name="traitement" placeholder="Ecrire ici"></textarea>
					<span class="focus-input100"></span>
				</div>
			</form>

<!--ligne tableau-->
<table class="default">				
<!--ligne ordonnance-->			
<caption class="ordonnance">ORDONNANCE</caption></br>
<thead>
   <tr>
      <th>N°</th>
      <th>Médicament</th>
      <th>Posologie</th>
   </tr>
</thead>

<tbody>
   <tr>
        <td>1</td>
      <td> 
        <div class="wrap-input100 validate-input">
          <input class="input100" type="texte" name="medicament1" placeholder="Nom du médicament">
          <span class="focus-input100"></span>
        </div>
      </td>

       <td>
		<div class="wrap-input100 validate-input">
			<input class="input100" type="texte" name="posologie1" placeholder="donner la posologie">
			<span class="focus-input100"></span>
			</div>       
       </td>
  	</tr>

     <tr>
        <td>2</td>
      <td> 
        <div class="wrap-input100 validate-input">
          <input class="input100" type="texte" name="medicament2" placeholder="Nom du médicament">
          <span class="focus-input100"></span>
        </div>
      </td>

       <td>
		<div class="wrap-input100 validate-input">
			<input class="input100" type="texte" name="posologie2" placeholder="donner la posologie">
			<span class="focus-input100"></span>
			</div>       
       </td>
  	</tr>

   <tr>
        <td>3</td>
      <td> 
        <div class="wrap-input100 validate-input">
          <input class="input100" type="texte" name="medicament3" placeholder="Nom du médicament">
          <span class="focus-input100"></span>
        </div>
      </td>

       <td>
		<div class="wrap-input100 validate-input">
			<input class="input100" type="texte" name="posologie3" placeholder="donner la posologie">
			<span class="focus-input100"></span>
			</div>       
       </td>
  	</tr>

  	   <tr>
        <td>4</td>
      <td> 
        <div class="wrap-input100 validate-input">
          <input class="input100" type="texte" name="medicament4" placeholder="Nom du médicament">
          <span class="focus-input100"></span>
        </div>
      </td>

       <td>
		<div class="wrap-input100 validate-input">
			<input class="input100" type="texte" name="posologie4" placeholder="donner la posologie">
			<span class="focus-input100"></span>
			</div>       
       </td>
  	</tr>

  	   <tr>
        <td>5</td>
      <td> 
        <div class="wrap-input100 validate-input">
          <input class="input100" type="texte" name="medicament5" placeholder="Nom du médicament">
          <span class="focus-input100"></span>
        </div>
      </td>

       <td>
		<div class="wrap-input100 validate-input">
			<input class="input100" type="texte" name="posologie5" placeholder="donner la posologie">
			<span class="focus-input100"></span>
			</div>       
       </td>
  	</tr>

  	   <tr>
        <td>6</td>
      <td> 
        <div class="wrap-input100 validate-input">
          <input class="input100" type="texte" name="medicament6" placeholder="Nom du médicament">
          <span class="focus-input100"></span>
        </div>
      </td>

       <td>
		<div class="wrap-input100 validate-input">
			<input class="input100" type="texte" name="posologie6" placeholder="donner la posologie">
			<span class="focus-input100"></span>
			</div>       
       </td>
  

</tbody>
</table>

<!--ligne de d'enregistrement-->
<form>
				<div class="container-medical-form-btn">
					<button class="medical-form-btn">
						<span>
							ENREGISTRER
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="false"></i>
						</span>
					</button>
				</div></form>
		</div>
	</div>

	<div id="dropDownSelect1"></div>

	<script src="js/main.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-23581568-13');
	</script>

</body>
</html>
