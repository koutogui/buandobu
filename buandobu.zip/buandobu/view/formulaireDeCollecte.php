﻿<!DOCTYPE html>
<html lang="en">
<head>
	<title>Formulaire de controle</title>
	<meta charset="UTF-8">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
</head>
<body class="bodyBg" style="background-image : url('images/bg-02c.jpg');">


	<div class="container-medical">
		<div class="wrap-medical">
			<div class="medical-form-title" style="background-image: url(images/bg-01.jpg);">
				<span class="nom-formulaire">
					FICHE DE CONTROLE
				</span>
				<span class="nom-patient">
					Nom du patient
				</span></br>
				<span class="ID-patient">
					IDENTIFIANT
				</span>
			</div>
			<form class="medical-form validate-form" action="collecte.php">
<!--ligne de saisie de la date-->
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Date</span>
					<input class="input100" type="date" name="dateControle">
					<span class="focus-input100"></span>
				</div>
<!--ligne de saisie de la temperature-->
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Température</span>
					<input class="input100" type="combo" name="temperature" placeholder="Enter la température (°C)">
					<span class="focus-input100"></span>
				</div>
<!--ligne de saisie le Pouls-->
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Pouls</span>
					<input class="input100" type="number" name="pouls" placeholder="Enter le pouls">
					<span class="focus-input100"></span>
				</div>
<!--ligne de saisie la tension arterielle-->
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Tension artérielle</span>
					<input class="input100" type="number" name="tension arterielle" placeholder="Enter la tension artérielle">
					<span class="focus-input100"></span>
				</div>
<!--ligne de saisie le poids-->
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Poids</span>
					<input class="input100" type="number" name="poids" placeholder="Enter le poids">
					<span class="focus-input100"></span>
				</div>
<!--ligne de saisie une plainte-->
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Plainte dominante</span>
					<textarea class="input100" name="plainteDominante" placeholder="Ecrire ici"></textarea>
					<span class="focus-input100"></span>
				</div>
<!--ligne de saisie un autre signe-->			
				<div class="wrap-input100 validate-input">
					<span class="label-input100">Autre signe</span>
					<textarea class="input100" name="autreSigne" placeholder="Ecrire ici"></textarea>
					<span class="focus-input100"></span>
				</div>
<!--ligne de d'enregistrement-->
				<div class="container-medical-form-btn">
					<button class="medical-form-btn">
						<span>
							ENREGISTRER
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="false"></i>
						</span>
					</button>
				</div>

			</form>
		</div>
	</div>



	<div id="dropDownSelect1"></div>

	<script src="js/main.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-23581568-13');
	</script>

</body>
</html>
